class GameState:
    def __init__(self):
        self.score = 0
        self.level = 1

    def add_score(self):
        self.score += 1
        print("Added score! Current score:", self.score)  # debug line