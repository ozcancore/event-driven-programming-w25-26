import pygame
import os
import json
from rafiki_basket.core import GameState

# ---------------- Window ----------------
WIDTH, HEIGHT = 800, 600
HIGH_SCORE_FILE = os.path.join(os.path.dirname(__file__), "high_scores.json")

# ---------------- UI Colors ----------------
BG_COLOR = (245, 240, 255)
PANEL_COLOR = (255, 255, 255)
TITLE_COLOR = (120, 80, 200)
TEXT_COLOR = (60, 60, 60)
HIGHLIGHT_COLOR = (255, 180, 80)

# ---------------- High Score Functions ----------------
def load_high_scores():
    if not os.path.exists(HIGH_SCORE_FILE):
        return {}
    with open(HIGH_SCORE_FILE, "r") as f:
        return json.load(f)

def save_high_scores(scores):
    with open(HIGH_SCORE_FILE, "w") as f:
        json.dump(scores, f)

def update_high_score(username, score):
    scores = load_high_scores()
    if username not in scores or score > scores[username]:
        scores[username] = score
        save_high_scores(scores)
        return True
    return False

# ---------------- Utility Functions ----------------
def show_message(screen, font, message, sub_message="", duration=2000):
    screen.fill(BG_COLOR)
    main_text = font.render(message, True, TITLE_COLOR)
    main_rect = main_text.get_rect(center=(WIDTH//2, HEIGHT//2 - 20))
    screen.blit(main_text, main_rect)
    if sub_message:
        sub_text = font.render(sub_message, True, TEXT_COLOR)
        sub_rect = sub_text.get_rect(center=(WIDTH//2, HEIGHT//2 + 20))
        screen.blit(sub_text, sub_rect)
    pygame.display.flip()
    pygame.time.delay(duration)

# ---------------- Login Screen ----------------
def login_screen(screen, font):
    username = ""
    while True:
        screen.fill(BG_COLOR)

        panel = pygame.Rect(150, 180, 500, 220)
        pygame.draw.rect(screen, PANEL_COLOR, panel, border_radius=20)

        title = font.render("Welcome to Rafiki Basketball", True, TITLE_COLOR)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 130))

        prompt = font.render("Enter your username:", True, TEXT_COLOR)
        screen.blit(prompt, (panel.x + 50, panel.y + 40))

        input_box = pygame.Rect(panel.x + 50, panel.y + 90, 400, 50)
        pygame.draw.rect(screen, (230, 230, 255), input_box, border_radius=12)

        name_text = font.render(username, True, TEXT_COLOR)
        screen.blit(name_text, (input_box.x + 10, input_box.y + 10))

        hint = font.render("Press ENTER to continue", True, (120, 120, 120))
        screen.blit(hint, (panel.x + 120, panel.y + 160))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN and username.strip():
                    return username.strip()
                elif event.key == pygame.K_BACKSPACE:
                    username = username[:-1]
                elif len(username) < 12:
                    username += event.unicode

# ---------------- Title Screen ----------------
def show_title_screen(screen, font, current_user):
    options = ["Start Game", "Login", "Quit"]
    selected = 0

    while True:
        screen.fill(BG_COLOR)

        # Title
        title_text = font.render("Rafiki Basketball", True, TITLE_COLOR)
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, 100))

        # Subtitle / description
        subtitle_text = font.render("A fun entertaining game", True, (140, 120, 180))
        screen.blit(subtitle_text, (WIDTH // 2 - subtitle_text.get_width() // 2, 150))

        # Options panel
        panel = pygame.Rect(250, 220, 300, 220)
        pygame.draw.rect(screen, PANEL_COLOR, panel, border_radius=20)

        for i, option in enumerate(options):
            color = HIGHLIGHT_COLOR if i == selected else TEXT_COLOR
            text = font.render(option, True, color)
            screen.blit(text, (panel.x + 80, panel.y + 30 + i * 60))

        if current_user:
            user_text = font.render(f"Logged in as: {current_user}", True, TEXT_COLOR)
            screen.blit(user_text, (20, 20))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected = (selected - 1) % len(options)
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(options)
                if event.key == pygame.K_RETURN:
                    return options[selected].lower().replace(" ", "")

# ---------------- Main Game ----------------
def run():
    pygame.init()
    pygame.font.init()
    pygame.mixer.init()

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Rafiki Basketball")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("arial", 36)

    assets_path = os.path.join(os.path.dirname(__file__), "assets")

    # Load images
    court_image = pygame.image.load(os.path.join(assets_path, "basketball_court.png"))
    court_image = pygame.transform.scale(court_image, (WIDTH, HEIGHT))

    rafiki_image_original = pygame.image.load(os.path.join(assets_path, "rafiki_charecter.png"))
    rafiki_image = pygame.transform.scale(rafiki_image_original, (200, 330))

    basketball_image = pygame.image.load(os.path.join(assets_path, "basketball.png"))
    basketball_image = pygame.transform.scale(basketball_image, (30, 30))

    hoop_image = pygame.image.load(os.path.join(assets_path, "basket_hoop.png"))
    hoop_image = pygame.transform.scale(hoop_image, (60, 60))

    spectators = [pygame.image.load(os.path.join(assets_path, f"spectator{i}.png")) for i in range(1, 4)]
    spectators = [pygame.transform.scale(img, (60, 100)) for img in spectators]
    spectator_positions = [(50, 400), (200, 420), (600, 410)]
    spectator_frame = 0

    # Sounds
    score_sound = pygame.mixer.Sound(os.path.join(assets_path, "score_short.wav"))
    levelup_sound = pygame.mixer.Sound(os.path.join(assets_path, "levelup.wav"))

    pygame.mixer.music.load(os.path.join(assets_path, "background.mp3"))
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1)

    # Login / Title Screen
    current_user = None
    while True:
        action = show_title_screen(screen, font, current_user)
        if action == "quit":
            return
        elif action == "login":
            username = login_screen(screen, font)
            if username:
                current_user = username
                break
        elif action == "start":
            if not current_user:
                show_message(screen, font, "Please login first!", "", 1500)
            else:
                break

    # ---------------- Game Variables ----------------
    game = GameState()
    rafiki_x = 100
    rafiki_y = 270
    rafiki_jump = False
    jump_speed = -15
    fall_speed = 0
    speed = 5
    ball_x = rafiki_x + 90
    ball_y = rafiki_y + 50
    ball_speed_y = 0
    ball_in_air = False
    gravity = 0.8
    hoop_width, hoop_height = 60, 60
    hoop_x, hoop_y = 600, 250
    hoop_speed, hoop_direction = 3, 1
    rim_width, rim_height = 40, 5
    rim_x_offset, rim_y_offset = 10, 40
    levels_config = [
        {"hoop_speed": 3, "hoop_y": 250, "gravity": 0.8},
        {"hoop_speed": 4, "hoop_y": 230, "gravity": 0.85},
        {"hoop_speed": 5, "hoop_y": 210, "gravity": 0.9},
        {"hoop_speed": 6, "hoop_y": 200, "gravity": 0.95},
        {"hoop_speed": 7, "hoop_y": 180, "gravity": 1.0},
    ]
    level, level_threshold = 0, 5
    hoop_speed = levels_config[level]["hoop_speed"]
    hoop_y = levels_config[level]["hoop_y"]
    gravity = levels_config[level]["gravity"]
    rafiki_flipping = False
    flip_angle = 0

    # ---------------- Main Loop ----------------
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_f:
                    rafiki_flipping = True
                    flip_angle = 0
                if event.key == pygame.K_l:
                    current_user = None
                    run()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            rafiki_x -= speed
        if keys[pygame.K_RIGHT]:
            rafiki_x += speed
        rafiki_x = max(0, min(rafiki_x, WIDTH - rafiki_image.get_width()))

        if keys[pygame.K_SPACE] and not rafiki_jump:
            rafiki_jump = True
            fall_speed = jump_speed

        if keys[pygame.K_UP] and not ball_in_air:
            ball_speed_y = max(-20, -10 - (level * 2))
            ball_in_air = True

        if rafiki_jump:
            rafiki_y += fall_speed
            fall_speed += gravity
            if rafiki_y >= 270:
                rafiki_y = 270
                rafiki_jump = False
                fall_speed = 0

        if ball_in_air:
            ball_y += ball_speed_y
            ball_speed_y += gravity
            if ball_y >= rafiki_y + 50:
                ball_y = rafiki_y + 50
                ball_in_air = False
                ball_speed_y = 0
        else:
            ball_x = rafiki_x + 90
            ball_y = rafiki_y + 50

        hoop_x += hoop_speed * hoop_direction
        if hoop_x <= 0 or hoop_x + hoop_width >= WIDTH:
            hoop_direction *= -1
        rim_x, rim_y = hoop_x + rim_x_offset, hoop_y + rim_y_offset

        if pygame.time.get_ticks() % 500 < 50:
            spectator_frame = (spectator_frame + 1) % len(spectators)

        screen.blit(court_image, (0, 0))
        for pos in spectator_positions:
            screen.blit(spectators[spectator_frame], pos)

        if rafiki_flipping:
            flip_angle += 15
            rotated_image = pygame.transform.rotate(rafiki_image, flip_angle)
            screen.blit(rotated_image, (rafiki_x, rafiki_y))
            if flip_angle >= 360:
                rafiki_flipping = False
        else:
            screen.blit(rafiki_image, (rafiki_x, rafiki_y))

        screen.blit(basketball_image, (int(ball_x - 15), int(ball_y - 15)))
        screen.blit(hoop_image, (int(hoop_x), int(hoop_y - 20)))

        if (rim_x < ball_x < rim_x + rim_width) and (rim_y < ball_y < rim_y + rim_height):
            if ball_in_air:
                game.add_score()
                ball_in_air = False
                ball_y = rafiki_y + 50
                score_sound.play()
        if (rim_x < ball_x < rim_x + rim_width) and (ball_y < rim_y):
            ball_speed_y *= -0.3

        if game.score >= (level + 1) * level_threshold and level < len(levels_config) - 1:
            level += 1
            hoop_speed = levels_config[level]["hoop_speed"]
            hoop_y = levels_config[level]["hoop_y"]
            gravity = levels_config[level]["gravity"]
            levelup_sound.play()
            show_message(screen, font, f"Level {level + 1} Complete!", "Get ready for next level!", 1500)

        if level == len(levels_config) - 1 and game.score >= (level + 1) * level_threshold:
            show_message(screen, font, "Congratulations!", "You completed the game!", 3000)
            running = False

        score_text = font.render(f"Score: {game.score} Level: {level + 1}", True, (60, 60, 60))
        screen.blit(score_text, (20, 20))
        if current_user:
            user_text = font.render(f"Logged in as: {current_user}", True, (60, 60, 60))
            screen.blit(user_text, (20, 60))

        pygame.display.flip()
        clock.tick(60)

    # ---------------- Game Over / High Score ----------------
    if current_user:
        is_new = update_high_score(current_user, game.score)
        if is_new:
            show_message(screen, font, "New High Score!", f"{current_user}: {game.score}", 2500)
        else:
            scores = load_high_scores()
            show_message(screen, font, "Game Over", f"{current_user} High Score: {scores[current_user]}", 2500)

    pygame.quit()

if __name__ == "__main__":
    run()
